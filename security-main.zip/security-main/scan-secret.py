import os
import re
import json
import csv
import math
import hashlib
from concurrent.futures import ThreadPoolExecutor
from collections import defaultdict

# ======================================
# CONFIG
# ======================================

TARGET_DIR = r"./repo"

OUTPUT_JSON = "findings.json"
OUTPUT_TXT = "findings.txt"
OUTPUT_CSV = "findings.csv"

MAX_FILE_SIZE = 20 * 1024 * 1024

THREADS = 20

EXCLUDED_DIRS = {
    ".git",
    "node_modules",
    "vendor",
    "__pycache__",
    ".idea",
    ".vscode",
    "dist",
    "build",
    "coverage",
    ".next",
    ".nuxt",
    "target",
    ".terraform",
    ".venv",
    "venv",
}

# ======================================
# PATTERNS
# ======================================

PATTERNS = {

    # AWS
    "AWS Access Key": r"AKIA[0-9A-Z]{16}",
    "AWS Secret": r"(?i)aws(.{0,20})?(secret|access)?.{0,5}[=:].{0,5}[\"']?[A-Za-z0-9\/+=]{40}[\"']?",
    "AWS Account ID": r"\b\d{12}\b",

    # GitHub
    "GitHub Token": r"github_pat_[A-Za-z0-9_]{20,255}|gh[pousr]_[A-Za-z0-9]{20,255}",

    # GitLab
    "GitLab Token": r"glpat-[A-Za-z0-9\-_]{20,}",

    # Slack
    "Slack Token": r"xox[baprs]-[A-Za-z0-9\-]+",

    # Stripe
    "Stripe Secret": r"sk_live_[0-9a-zA-Z]{24,}",

    # Twilio
    "Twilio SID": r"AC[a-f0-9]{32}",

    # SendGrid
    "SendGrid Key": r"SG\.[A-Za-z0-9_\-]{20,}\.[A-Za-z0-9_\-]{20,}",

    # Mailgun
    "Mailgun Key": r"key-[0-9a-zA-Z]{32}",

    # Firebase
    "Firebase URL": r"https:\/\/[A-Za-z0-9-]+\.firebaseio\.com",

    # Supabase
    "Supabase URL": r"https:\/\/[A-Za-z0-9\-]+\.supabase\.co",

    # JWT
    "JWT": r"eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9._-]+\.[A-Za-z0-9._-]+",

    # Bearer
    "Bearer Token": r"Bearer\s+[A-Za-z0-9\-._~+/]+=*",

    # Basic auth
    "Basic Auth": r"basic\s+[A-Za-z0-9=:_\+\/-]{10,}",

    # OAuth
    "OAuth Secret": r"(?i)(client_secret|oauth_secret)\s*[:=]\s*[\"'][^\"']+[\"']",

    # API keys
    "API Key": r"(?i)(api[_-]?key|apikey|secret|token)\s*[:=]\s*[\"'][^\"']{8,}[\"']",

    # Passwords
    "Password": r"(?i)(password|passwd|pwd)\s*[:=]\s*[\"'][^\"']{3,}[\"']",

    # Connection strings
    "DB Connection": r"(?i)(mysql|postgres|mongodb|redis|amqp):\/\/[^\s]+",

    # Private keys
    "Private Key": r"-----BEGIN (RSA|DSA|EC|OPENSSH|PGP)? PRIVATE KEY-----",

    # SSH
    "SSH Public Key": r"ssh-rsa AAAA[0-9A-Za-z+/]+",

    # PEM
    "PEM Cert": r"-----BEGIN CERTIFICATE-----",

    # Webhooks
    "Discord Webhook": r"https:\/\/discord\.com\/api\/webhooks\/[0-9]+\/[A-Za-z0-9_\-]+",

    "Slack Webhook": r"https:\/\/hooks\.slack\.com\/services\/[A-Za-z0-9\/]+",

    # URLs
    "URL": r"https?:\/\/[A-Za-z0-9\-._~:\/?#\[\]@!$&'()*+,;=%]+",

    # Internal IPs
    "Internal IP": r"\b(10\.\d{1,3}\.\d{1,3}\.\d{1,3}|192\.168\.\d{1,3}\.\d{1,3}|172\.(1[6-9]|2\d|3[0-1])\.\d{1,3}\.\d{1,3})\b",

    # Internal domains
    "Internal Domain": r"\b[A-Za-z0-9._-]+\.(local|internal|corp|lan)\b",

    # Emails
    "Email": r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}",

    # S3
    "S3 Bucket": r"[A-Za-z0-9.-]+\.s3\.amazonaws\.com",

    # Azure storage
    "Azure Storage": r"DefaultEndpointsProtocol=https;AccountName=.*;AccountKey=.*",

    # Google API
    "Google API Key": r"AIza[0-9A-Za-z\-_]{35}",

    # Heroku
    "Heroku API": r"(?i)heroku(.{0,20})?[0-9a-f]{32}",

    # Debug configs
    "Debug Enabled": r"(?i)(debug|dev_mode)\s*[:=]\s*(true|1)",

    # Dangerous localhost
    "Localhost Ref": r"http:\/\/(127\.0\.0\.1|localhost)",

    # Kubernetes
    "Kubeconfig": r"apiVersion:\s*v1",

    # Docker auth
    "Docker Auth": r"auths",

    # JWT secret
    "JWT Secret": r"(?i)(jwt_secret|jwtKey|jwt-key)\s*[:=]\s*[\"'][^\"']+[\"']",

    # Encryption keys
    "Encryption Key": r"(?i)(encryption_key|aes_key|secret_key)\s*[:=]\s*[\"'][^\"']+[\"']",
}

# ======================================
# ENTROPY
# ======================================

def entropy(data):
    if not data:
        return 0

    ent = 0

    for x in set(data):
        p_x = float(data.count(x)) / len(data)
        ent += - p_x * math.log2(p_x)

    return ent

def high_entropy(s):
    return len(s) > 20 and entropy(s) > 4.5

# ======================================
# HELPERS
# ======================================

def is_binary(path):
    try:
        with open(path, "rb") as f:
            chunk = f.read(1024)
            return b"\0" in chunk
    except:
        return True

def sha1(x):
    return hashlib.sha1(x.encode()).hexdigest()

# ======================================
# FILE SCANNER
# ======================================

findings = []

def scan_file(filepath):

    local_findings = []

    try:
        if os.path.getsize(filepath) > MAX_FILE_SIZE:
            return []
    except:
        return []

    if is_binary(filepath):
        return []

    try:
        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
            lines = f.readlines()
    except:
        return []

    for lineno, line in enumerate(lines, start=1):

        # regex checks
        for category, pattern in PATTERNS.items():

            try:
                matches = re.findall(pattern, line)

                if matches:

                    local_findings.append({
                        "type": category,
                        "file": filepath,
                        "line": lineno,
                        "content": line.strip()[:500]
                    })

            except:
                pass

        # entropy checks
        strings = re.findall(r"[A-Za-z0-9\/+=._-]{20,}", line)

        for s in strings:

            if high_entropy(s):

                local_findings.append({
                    "type": "High Entropy Secret",
                    "file": filepath,
                    "line": lineno,
                    "content": s[:500]
                })

    return local_findings

# ======================================
# WALK FILES
# ======================================

all_files = []

for root, dirs, files in os.walk(TARGET_DIR):

    dirs[:] = [d for d in dirs if d not in EXCLUDED_DIRS]

    for file in files:

        path = os.path.join(root, file)

        all_files.append(path)

# ======================================
# MULTITHREAD SCAN
# ======================================

with ThreadPoolExecutor(max_workers=THREADS) as executor:

    results = executor.map(scan_file, all_files)

    for result in results:
        findings.extend(result)

# ======================================
# REMOVE DUPES
# ======================================

unique = []
seen = set()

for item in findings:

    key = sha1(
        item["type"] +
        item["file"] +
        str(item["line"]) +
        item["content"]
    )

    if key not in seen:
        seen.add(key)
        unique.append(item)

findings = unique

# ======================================
# SAVE JSON
# ======================================

with open(OUTPUT_JSON, "w", encoding="utf-8") as f:
    json.dump(findings, f, indent=4)

# ======================================
# SAVE CSV
# ======================================

with open(OUTPUT_CSV, "w", newline="", encoding="utf-8") as csvfile:

    writer = csv.writer(csvfile)

    writer.writerow(["Type", "File", "Line", "Content"])

    for item in findings:
        writer.writerow([
            item["type"],
            item["file"],
            item["line"],
            item["content"]
        ])

# ======================================
# SAVE TXT
# ======================================

summary = defaultdict(int)

for item in findings:
    summary[item["type"]] += 1

with open(OUTPUT_TXT, "w", encoding="utf-8") as f:

    f.write("==== SECRET SCAN SUMMARY ====\n\n")

    for k, v in sorted(summary.items()):
        f.write(f"{k}: {v}\n")

    f.write(f"\nTotal Findings: {len(findings)}\n\n")

    f.write("==== DETAILED FINDINGS ====\n\n")

    for item in findings:

        f.write(
            f"[{item['type']}] "
            f"{item['file']}:{item['line']}\n"
        )

        f.write(f"{item['content']}\n")
        f.write("-" * 80 + "\n")

# ======================================
# DONE
# ======================================

print("\n==============================")
print("SCAN COMPLETE")
print("==============================")

print(f"\nFiles Scanned: {len(all_files)}")
print(f"Findings: {len(findings)}")

print(f"\nJSON: {OUTPUT_JSON}")
print(f"CSV : {OUTPUT_CSV}")
print(f"TXT : {OUTPUT_TXT}")
