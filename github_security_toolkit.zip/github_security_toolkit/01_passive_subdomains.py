#!/usr/bin/env python3
"""Passive subdomain discovery from certificate-transparency data via crt.sh."""
import argparse, json, sys, urllib.parse, urllib.request

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("domain", help="Authorized domain, e.g. example.com")
    p.add_argument("-o", "--output")
    a = p.parse_args()
    domain = a.domain.lower().strip().lstrip("*.")
    if not domain or "." not in domain or any(c in domain for c in "/:@ "):
        p.error("Provide a plain domain name, not a URL or IP.")
    url = "https://crt.sh/?" + urllib.parse.urlencode({"q": "%." + domain, "output": "json"})
    req = urllib.request.Request(url, headers={"User-Agent": "ResearchToolkit/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            rows = json.loads(r.read().decode("utf-8", "replace"))
    except Exception as e:
        print(f"[!] Query failed: {e}", file=sys.stderr); sys.exit(1)
    names = set()
    for row in rows:
        for n in row.get("name_value", "").splitlines():
            n = n.strip().lower().lstrip("*.")
            if n == domain or n.endswith("." + domain):
                names.add(n)
    out = sorted(names)
    print(f"[+] {len(out)} unique names found for {domain}")
    print("\n".join(out))
    if a.output:
        with open(a.output, "w", encoding="utf-8") as f:
            f.write("\n".join(out) + ("\n" if out else ""))
        print(f"[+] Saved to {a.output}")

if __name__ == "__main__": main()
