#!/usr/bin/env python3
"""Compare two authorized test identities against one read-only HTTPS API endpoint."""
import argparse, hashlib, urllib.error, urllib.request

def fetch(url, token, timeout):
    req = urllib.request.Request(url, headers={
        "User-Agent": "ResearchToolkit/1.0", "Accept": "application/json",
        "Authorization": "Bearer " + token
    }, method="GET")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, r.headers.get("Content-Type", ""), r.read(500_000)
    except urllib.error.HTTPError as e:
        return e.code, e.headers.get("Content-Type", ""), e.read(500_000)
    except Exception as e:
        return None, "", str(e).encode()
def fp(body): return hashlib.sha256(body).hexdigest()[:16]
def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("url", help="One endpoint in an authorized test environment")
    p.add_argument("--token-a", required=True, help="Token for test account A")
    p.add_argument("--token-b", required=True, help="Token for test account B")
    p.add_argument("--timeout", type=float, default=10)
    a = p.parse_args()
    if not a.url.startswith("https://"): p.error("Use HTTPS.")
    if a.token_a == a.token_b: p.error("Tokens must represent different test identities.")
    one, two = fetch(a.url, a.token_a, a.timeout), fetch(a.url, a.token_b, a.timeout)
    print(f"[A] status={one[0]} content-type={one[1]} body-hash={fp(one[2])}")
    print(f"[B] status={two[0]} content-type={two[1]} body-hash={fp(two[2])}")
    if one[0] in (401,403) and two[0] in (401,403):
        print("[RESULT] Both identities were denied.")
    elif one[0] != two[0] or fp(one[2]) != fp(two[2]):
        print("[RESULT] Responses differ; inspect with test accounts to determine whether behavior is expected.")
    else:
        print("[RESULT] Responses match. This does not prove authorization is correct.")
    print("[!] GET-only comparison. Differences are leads, not proof; never use other people's tokens.")
if __name__ == "__main__": main()
