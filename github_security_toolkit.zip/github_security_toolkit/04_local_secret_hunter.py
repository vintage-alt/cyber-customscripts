#!/usr/bin/env python3
"""Scan a local code directory for likely secrets; output attempts to redact values."""
import argparse, re
from pathlib import Path

SKIP_DIRS = {".git", ".svn", ".hg", "node_modules", ".venv", "venv", "__pycache__", "vendor", "dist", "build"}
SKIP_EXTS = {".png",".jpg",".jpeg",".gif",".pdf",".zip",".gz",".exe",".dll",".so",".pyc",".class"}
PATTERNS = [
    ("AWS access key ID", re.compile(r"\bAKIA[0-9A-Z]{16}\b")),
    ("Private key block", re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----")),
    ("GitHub token-like value", re.compile(r"\b(?:gh[pousr]_[A-Za-z0-9_]{30,}|github_pat_[A-Za-z0-9_]{30,})\b")),
    ("Credential assignment", re.compile(r"""(?i)\b(?:api[_-]?key|client[_-]?secret|access[_-]?token|password|passwd|secret)\b\s*[:=]\s*["']?[A-Za-z0-9_./+=-]{8,}""")),
    ("JWT-like string", re.compile(r"\beyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\b")),
]
def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("path", help="Local repository or directory")
    p.add_argument("--max-bytes", type=int, default=1_000_000)
    a = p.parse_args()
    root = Path(a.path).expanduser().resolve()
    if not root.exists(): p.error("Path does not exist.")
    candidates = [root] if root.is_file() else (
        f for f in root.rglob("*") if f.is_file() and not (set(f.parts) & SKIP_DIRS) and f.suffix.lower() not in SKIP_EXTS
    )
    count = 0
    for file in candidates:
        try:
            if file.stat().st_size > a.max_bytes: continue
            lines = file.read_text(encoding="utf-8", errors="ignore").splitlines()
        except OSError: continue
        for num, line in enumerate(lines, 1):
            for label, pattern in PATTERNS:
                if pattern.search(line):
                    preview = re.sub(r"""(?i)(=|:)\s*["']?[^,\s"']{6,}""", r"\1 [REDACTED]", line.strip())[:120]
                    print(f"{file}:{num}: {label} | {preview}")
                    count += 1
                    break
    print(f"\n[*] {count} possible finding(s); false positives are expected.")
    print("[!] Redaction is best-effort. Run locally and inspect results before publishing.")
if __name__ == "__main__": main()
