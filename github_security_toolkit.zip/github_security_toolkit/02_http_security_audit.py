#!/usr/bin/env python3
"""Check HTTP security headers and basic TLS certificate details for one URL."""
import argparse, socket, ssl, urllib.error, urllib.request
from urllib.parse import urlparse

CHECKS = {
    "strict-transport-security": "Helps enforce HTTPS.",
    "content-security-policy": "Helps mitigate content injection and XSS.",
    "x-content-type-options": "Prefer nosniff to reduce MIME sniffing.",
    "referrer-policy": "Controls referrer information.",
    "permissions-policy": "Restricts browser features.",
}
def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("url", help="Authorized URL, e.g. https://app.example.com/")
    a = p.parse_args()
    url = a.url if "://" in a.url else "https://" + a.url
    u = urlparse(url)
    if u.scheme not in ("http", "https") or not u.hostname: p.error("Provide a valid HTTP(S) URL.")
    if u.scheme == "https":
        try:
            ctx = ssl.create_default_context()
            with socket.create_connection((u.hostname, u.port or 443), timeout=8) as s:
                with ctx.wrap_socket(s, server_hostname=u.hostname) as t:
                    cert = t.getpeercert()
                    print(f"[TLS] Version: {t.version()}")
                    print(f"[TLS] Certificate expires: {cert.get('notAfter', 'unknown')}")
        except Exception as e: print(f"[TLS] Check failed: {e}")
    req = urllib.request.Request(url, headers={"User-Agent": "ResearchToolkit/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=12) as r: status, headers = r.status, r.headers
    except urllib.error.HTTPError as e: status, headers = e.code, e.headers
    except Exception as e: print(f"[!] Request failed: {e}"); return
    h = {k.lower(): v for k, v in headers.items()}
    print(f"\n[HTTP] Status: {status} | URL: {url}")
    for name, desc in CHECKS.items():
        print(f"[{'OK' if name in h else 'MISSING'}] {name}: {desc}")
    csp = h.get("content-security-policy", "").lower()
    print(f"[{'OK' if 'frame-ancestors' in csp else 'REVIEW'}] CSP frame-ancestors: review framing policy")
    for name in ("server", "x-powered-by"):
        if name in h: print(f"[INFO] {name}: {h[name]}")
    print("Note: missing headers are observations, not automatically vulnerabilities.")
if __name__ == "__main__": main()
