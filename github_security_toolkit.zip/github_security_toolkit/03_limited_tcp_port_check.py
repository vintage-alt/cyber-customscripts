#!/usr/bin/env python3
"""Low-rate TCP port reachability check for an authorized host."""
import argparse, socket, sys
COMMON = [21,22,25,53,80,110,139,143,443,445,3306,3389,5432,5900,6379,8000,8080,8443,9200,27017]
def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("host", help="Hostname/IP within approved scope")
    p.add_argument("--ports", default="common", help="'common' or e.g. 22,80,443,8000-8010")
    p.add_argument("--timeout", type=float, default=0.6)
    a = p.parse_args()
    if not 0.1 <= a.timeout <= 3: p.error("--timeout must be between 0.1 and 3 seconds")
    if a.ports == "common": ports = COMMON
    else:
        ports = set()
        try:
            for item in a.ports.split(","):
                if "-" in item:
                    lo, hi = map(int, item.split("-", 1))
                    if lo > hi or hi-lo > 1000: raise ValueError("range too wide or reversed")
                    ports.update(range(lo, hi+1))
                else: ports.add(int(item))
            if any(x < 1 or x > 65535 for x in ports): raise ValueError("ports must be 1-65535")
            ports = sorted(ports)
        except ValueError as e: p.error(f"Invalid --ports: {e}")
    try: ip = socket.getaddrinfo(a.host, None, type=socket.SOCK_STREAM)[0][4][0]
    except socket.gaierror as e: print(f"[!] DNS resolution failed: {e}", file=sys.stderr); sys.exit(1)
    print(f"[*] Target {a.host} ({ip}); checking {len(ports)} TCP ports")
    count = 0
    for port in ports:
        try:
            with socket.create_connection((a.host, port), timeout=a.timeout): print(f"[OPEN] {port}/tcp"); count += 1
        except OSError: pass
    print(f"[*] Complete: {count} open port(s) observed.")
    print("[!] This checks TCP reachability only; it does not identify a vulnerability.")
if __name__ == "__main__": main()
