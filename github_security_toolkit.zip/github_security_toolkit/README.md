# Python Security Research Toolkit

Five dependency-free Python utilities for **authorized** security testing.

1. `01_passive_subdomains.py` — passive certificate-transparency discovery through crt.sh.
2. `02_http_security_audit.py` — HTTP security-header observations and TLS certificate checks.
3. `03_limited_tcp_port_check.py` — low-rate TCP checks for common or explicitly selected ports.
4. `04_local_secret_hunter.py` — local repository scan for likely secrets with redacted output.
5. `05_readonly_api_auth_diff.py` — compares two authorized identities against one HTTPS GET endpoint.

## Requirements
Python 3.10+; standard library only.

## Examples
```bash
python 01_passive_subdomains.py example.com -o subdomains.txt
python 02_http_security_audit.py https://app.example.com/
python 03_limited_tcp_port_check.py app.example.com --ports common
python 03_limited_tcp_port_check.py 192.0.2.10 --ports 22,80,443,8000-8010
python 04_local_secret_hunter.py ./my-project
python 05_readonly_api_auth_diff.py https://staging.example.com/api/me --token-a "$TOKEN_A" --token-b "$TOKEN_B"
```

Use only on assets/accounts you own or have explicit permission to assess. Findings are leads for manual validation, not proof of vulnerability. Never commit live credentials, cookies, private keys, or sensitive output. The secret scanner's redaction is best-effort, so review output locally.
