#!/bin/bash

set -euo pipefail

DOMAIN_LIST="all-domains.txt"
GLOBAL_KNOWN="subdomains.txt"
DATA_DIR="data"
NEW_DIR="new_subs"
LOG_FILE="monitor.log"
TODAY=$(date +%F)

mkdir -p "$DATA_DIR" "$NEW_DIR"
touch "$GLOBAL_KNOWN"

# Strong normalization
normalize() {
    sed 's/\r$//' | sed 's/\.$//' | tr '[:upper:]' '[:lower:]' \
    | awk '{$1=$1};1' | sort -u
}

log() {
    echo "[$(date '+%F %T')] $1" | tee -a "$LOG_FILE"
}

# Normalize global file once at startup
normalize < "$GLOBAL_KNOWN" > "${GLOBAL_KNOWN}.tmp"
mv "${GLOBAL_KNOWN}.tmp" "$GLOBAL_KNOWN"

while read -r raw_domain || [[ -n "$raw_domain" ]]; do

    # Normalize input domain
    domain=$(echo "$raw_domain" | normalize)

    [ -z "$domain" ] && continue

    log "Processing $domain"

    DOMAIN_FILE="$DATA_DIR/$domain.txt"
    TMP_FILE=$(mktemp)
    NEW_FILE="$NEW_DIR/${TODAY}_$domain.txt"

    # Run enumeration safely (subfinder + amass)

	ENUM_TMP=$(mktemp)

	{
	    subfinder -d "$domain" --all -silent 2>/dev/null
	    assetfinder --subs-only "$domain"
	    amass enum -passive -norecursive -noalts -d "$domain" 2>/dev/null
	} >> "$ENUM_TMP"

	if [ ! -s "$ENUM_TMP" ]; then
	    log "Enumeration failed for $domain"
	    rm -f "$TMP_FILE" "$ENUM_TMP"
	    continue
	fi

	# Normalize combined output
	normalize < "$ENUM_TMP" > "$TMP_FILE"
	rm -f "$ENUM_TMP"

    # If first time seeing this domain
    if [ ! -f "$DOMAIN_FILE" ]; then
        log "First run for $domain"

        cp "$TMP_FILE" "$DOMAIN_FILE"
        cat "$TMP_FILE" >> "$GLOBAL_KNOWN"

        normalize < "$GLOBAL_KNOWN" > "${GLOBAL_KNOWN}.tmp"
        mv "${GLOBAL_KNOWN}.tmp" "$GLOBAL_KNOWN"

        rm -f "$TMP_FILE"
        continue
    fi

    # Normalize stored domain file
    normalize < "$DOMAIN_FILE" > "${DOMAIN_FILE}.norm"
    mv "${DOMAIN_FILE}.norm" "$DOMAIN_FILE"

    # Find TRUE new subdomains (against domain file)
    comm -13 "$DOMAIN_FILE" "$TMP_FILE" > "$NEW_FILE"

    if [ -s "$NEW_FILE" ]; then
        log "New subdomains found for $domain"

        cat "$NEW_FILE" | tee -a "$LOG_FILE"

        # Update domain file
        cat "$NEW_FILE" >> "$DOMAIN_FILE"
        normalize < "$DOMAIN_FILE" > "${DOMAIN_FILE}.tmp"
        mv "${DOMAIN_FILE}.tmp" "$DOMAIN_FILE"

        # Update global file
        cat "$NEW_FILE" >> "$GLOBAL_KNOWN"
        normalize < "$GLOBAL_KNOWN" > "${GLOBAL_KNOWN}.tmp"
        mv "${GLOBAL_KNOWN}.tmp" "$GLOBAL_KNOWN"

    else
        log "No new subdomains for $domain"
        rm -f "$NEW_FILE"
    fi

    rm -f "$TMP_FILE"

done < "$DOMAIN_LIST"

log "Scan completed"
bash scripts/pipeline.sh "$NEW_FILE"


######################################################################################
#!/bin/bash

set -euo pipefail

DOMAIN_LIST="all-domains.txt"
GLOBAL_KNOWN="subdomains.txt"
DATA_DIR="data"
NEW_DIR="new_subs"
LOG_FILE="monitor.log"
TODAY=$(date +%F)

mkdir -p "$DATA_DIR" "$NEW_DIR"
touch "$GLOBAL_KNOWN"

# Normalization
normalize() {
    sed 's/\r$//' | sed 's/\.$//' | tr '[:upper:]' '[:lower:]' \
    | awk '{$1=$1};1' | sort -u
}

log() {
    echo "[$(date '+%F %T')] $1" | tee -a "$LOG_FILE"
}

# Normalize global file once
normalize < "$GLOBAL_KNOWN" > "${GLOBAL_KNOWN}.tmp"
mv "${GLOBAL_KNOWN}.tmp" "$GLOBAL_KNOWN"

while read -r raw_domain || [[ -n "$raw_domain" ]]; do

    domain=$(echo "$raw_domain" | normalize)

    [ -z "$domain" ] && continue

    log "Processing $domain"

    DOMAIN_FILE="$DATA_DIR/$domain.txt"
    TMP_FILE=$(mktemp)
    ENUM_TMP=$(mktemp)
    NEW_FILE="$NEW_DIR/${TODAY}_${domain}.txt"

    ########################################
    # ENUMERATION
    ########################################

    (
        timeout 5m subfinder -d "$domain" --all -silent 2>/dev/null || true
        timeout 5m assetfinder --subs-only "$domain" 2>/dev/null || true
        timeout 5m amass enum -passive -norecursive -noalts -d "$domain" 2>/dev/null || true

        if command -v findomain >/dev/null 2>&1; then
            timeout 5m findomain -t "$domain" -q 2>/dev/null || true
        fi

    ) >> "$ENUM_TMP"

    if [ ! -s "$ENUM_TMP" ]; then
        log "Enumeration failed for $domain"
        rm -f "$TMP_FILE" "$ENUM_TMP"
        continue
    fi

    normalize < "$ENUM_TMP" > "$TMP_FILE"
    rm -f "$ENUM_TMP"

    ########################################
    # FIRST RUN BASELINE
    ########################################

    if [ ! -f "$DOMAIN_FILE" ]; then

        log "First run baseline for $domain"

        cp "$TMP_FILE" "$DOMAIN_FILE"
        cat "$TMP_FILE" >> "$GLOBAL_KNOWN"

        normalize < "$GLOBAL_KNOWN" > "${GLOBAL_KNOWN}.tmp"
        mv "${GLOBAL_KNOWN}.tmp" "$GLOBAL_KNOWN"

        rm -f "$TMP_FILE"
        continue
    fi

    ########################################
    # NORMALIZE STORED DOMAIN FILE
    ########################################

    normalize < "$DOMAIN_FILE" > "${DOMAIN_FILE}.norm"
    mv "${DOMAIN_FILE}.norm" "$DOMAIN_FILE"

    ########################################
    # FIND TRUE NEW SUBDOMAINS
    ########################################

    comm -13 "$DOMAIN_FILE" "$TMP_FILE" > "$NEW_FILE"

    if [ -s "$NEW_FILE" ]; then

        log "New subdomains found for $domain"
        cat "$NEW_FILE" | tee -a "$LOG_FILE"

        ########################################
        # UPDATE DOMAIN FILE
        ########################################

        cat "$NEW_FILE" >> "$DOMAIN_FILE"
        normalize < "$DOMAIN_FILE" > "${DOMAIN_FILE}.tmp"
        mv "${DOMAIN_FILE}.tmp" "$DOMAIN_FILE"

        ########################################
        # UPDATE GLOBAL FILE
        ########################################

        cat "$NEW_FILE" >> "$GLOBAL_KNOWN"
        normalize < "$GLOBAL_KNOWN" > "${GLOBAL_KNOWN}.tmp"
        mv "${GLOBAL_KNOWN}.tmp" "$GLOBAL_KNOWN"

        ########################################
        # TRIGGER PIPELINE
        ########################################

        if [ -f scripts/pipeline.sh ]; then
            bash scripts/pipeline.sh "$NEW_FILE"
        fi

    else

        log "No new subdomains for $domain"
        rm -f "$NEW_FILE"

    fi

    rm -f "$TMP_FILE"

done < "$DOMAIN_LIST"

log "Scan completed"
