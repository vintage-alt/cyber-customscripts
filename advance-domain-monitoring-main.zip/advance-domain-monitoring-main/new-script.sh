#!/bin/bash

set -euo pipefail

DOMAIN_LIST="all-domains.txt"
GLOBAL_KNOWN="subdomains.txt"
DATA_DIR="data"
NEW_DIR="new_subs"
LOG_FILE="monitor.log"
TODAY=$(date +%F)

mkdir -p "$DATA_DIR" "$NEW_DIR"
touch "$GLOBAL_KNOWN"

# Strong normalization for lists
normalize_list() {
    sed 's/\r$//; s/\.$//' | tr '[:upper:]' '[:lower:]' | awk '{$1=$1};1' | sort -u
}

# Quick normalization for a single string (avoids subshell sorting bugs)
normalize_string() {
    echo "$1" | sed 's/\r$//; s/\.$//' | tr '[:upper:]' '[:lower:]' | awk '{$1=$1};1'
}

log() {
    echo "[$(date '+%F %T')] $1" | tee -a "$LOG_FILE"
}

# Normalize global file once at startup
normalize_list < "$GLOBAL_KNOWN" > "${GLOBAL_KNOWN}.tmp"
mv "${GLOBAL_KNOWN}.tmp" "$GLOBAL_KNOWN"

while read -r raw_domain || [[ -n "$raw_domain" ]]; do
    # Strip whitespace/newlines safely
    [[ -z "${raw_domain//[:space:]/}" ]] && continue
    
    domain=$(normalize_string "$raw_domain")
    [ -z "$domain" ] && continue

    log "Processing $domain"

    DOMAIN_FILE="$DATA_DIR/$domain.txt"
    TMP_FILE=$(mktemp)
    NEW_FILE="$NEW_DIR/${TODAY}_$domain.txt"

    # Run subfinder safely. Allow it to fail without crashing pipefail.
    if ! subfinder -d "$domain" --all -silent 2>/dev/null | normalize_list > "$TMP_FILE"; then
        log "Subfinder failed or found nothing for $domain"
        rm -f "$TMP_FILE"
        continue
    fi

    # If first time seeing this domain
    if [ ! -f "$DOMAIN_FILE" ]; then
        log "First run for $domain"
        cp "$TMP_FILE" "$DOMAIN_FILE"
        cat "$TMP_FILE" >> "$GLOBAL_KNOWN"
        rm -f "$TMP_FILE"
        continue
    fi

    # Ensure local file is sorted/normalized before comm
    normalize_list < "$DOMAIN_FILE" > "${DOMAIN_FILE}.norm"
    mv "${DOMAIN_FILE}.norm" "$DOMAIN_FILE"

    # Find TRUE new subdomains (Change $DOMAIN_FILE to $GLOBAL_KNOWN here if you want global uniqueness!)
    comm -13 "$DOMAIN_FILE" "$TMP_FILE" > "$NEW_FILE"

    if [ -s "$NEW_FILE" ]; then
        log "New subdomains found for $domain"
        cat "$NEW_FILE" >> "$LOG_FILE"

        # Update domain file
        cat "$NEW_FILE" >> "$DOMAIN_FILE"
        normalize_list < "$DOMAIN_FILE" > "${DOMAIN_FILE}.tmp"
        mv "${DOMAIN_FILE}.tmp" "$DOMAIN_FILE"

        # Append to global file (We will sort/dedup this ONCE at the end)
        cat "$NEW_FILE" >> "$GLOBAL_KNOWN"
    else
        log "No new subdomains for $domain"
        rm -f "$NEW_FILE"
    fi

    rm -f "$TMP_FILE"

done < "$DOMAIN_LIST"

# Deduplicate global file ONCE at the very end to save massive CPU/Disk cycles
log "Deduplicating global tracking file..."
normalize_list < "$GLOBAL_KNOWN" > "${GLOBAL_KNOWN}.tmp"
mv "${GLOBAL_KNOWN}.tmp" "$GLOBAL_KNOWN"

log "Scan completed"
